﻿using System;
using System.Linq;
using System.Windows.Forms;
using CodeX;
using CodeX.IO;
using CodeX.Windows.Forms;
using CodeX.Strings;
namespace SamplePasswordStorageApplication
{
    public partial class Form1 : RichForm
    {
        private const string _encryptedFileName = "encryptedFile.dat";
        private string _encryptionKey;
        private EncryptedData _data;
        public Form1(EncryptedData data, string encryptionKey)
        {
            InitializeComponent();
            AutoApplytThemeToControls = true;
            ApplyThemeFromConfiguration();
            Title.Text = "Password Storage Application";
            _encryptionKey = encryptionKey;
            _data = data;
            cmbPasswordList.DataSource = data.Infos.Select(x => x.Name).ToList();
            var selected = ThemeList.First(x => x.Selected);
            cmbThemeList.DataSource = ThemeList;
            cmbThemeList.DisplayMember = "Name";
            cmbThemeList.SelectedItem = selected;
        }

        private void cmbPasswordList_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtPassword.Text = _data.Infos.First(x => x.Name.Equals(cmbPasswordList.Text)).Password;
            txtUserName.Text = _data.Infos.First(x => x.Name.Equals(cmbPasswordList.Text)).UserName;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            cmbPasswordList.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtUserName.Text = string.Empty;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            cmbPasswordList.DataSource = _data.Infos.Select(x => x.Name).ToList();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text.IsNullOrEmpty() || txtUserName.Text.IsNullOrEmpty() || cmbPasswordList.Text.IsNullOrEmpty())
            {
                "All fields are required, do not leave anything empty".ShowError();
                return;
            }
            var existing = _data.Infos.FirstOrDefault(x => x.Name.Equals(cmbPasswordList.Text));

            if (existing == null)
            {
                existing = new LoginInfo();
                _data.Infos.Add(existing);
            }

            existing.Name = cmbPasswordList.Text;
            existing.UserName = txtUserName.Text;
            existing.Password = txtPassword.Text.Encrypt(_encryptionKey);

            _encryptedFileName.AsFile(true).WriteText(_data.ToXml<EncryptedData>().Encrypt(_encryptionKey));
            cmbPasswordList.DataSource = _data.Infos.Select(x => x.Name).ToList();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(!_data.Infos.Any(x => x.Name.Equals(cmbPasswordList.Text))) return;
            _data.Infos.Remove(_data.Infos.First(x => x.Name.Equals(cmbPasswordList.Text)));
            cmbPasswordList.DataSource = _data.Infos.Select(x => x.Name).ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtPassword.Text.Decrypt(_encryptionKey).ShowInformation("Decrypted Password");
        }

        private void cmbThemeList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyThemeFromConfiguration(cmbThemeList.SelectedItem as ThemeConfiguration);
        }

        private void Form1_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
