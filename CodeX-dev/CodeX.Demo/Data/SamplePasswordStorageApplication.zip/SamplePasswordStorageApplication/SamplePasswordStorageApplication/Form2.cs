﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CodeX;
using CodeX.IO;
using CodeX.Windows.Forms;
using CodeX.Strings;
namespace SamplePasswordStorageApplication
{
    public partial class Form2 : RichForm   
    {
        private const string _encryptedFileName = "encryptedFile.dat";

        public Form2()
        {
            InitializeComponent();
            AutoApplytThemeToControls = true;
            ApplyThemeFromConfiguration();
            Title.Text = "Enter your encryption Key";
        }

        private void button1_Click(object sender, EventArgs e)
        {
           if (txtEncryptionKey.Text.IsNullOrEmpty() || txtEncryptionKey.Text.IsNullOrWhiteSpace())
           {
               "Encryption key cannot be empty".ShowError();
               return;
           }
            EncryptedData encryptedData = null;
            if (_encryptedFileName.AsFile().Exists)
            {
                try
                {
                    var decryptedXml = _encryptedFileName.AsFile().ReadAsText().Decrypt(txtEncryptionKey.Text);
                    if (!decryptedXml.IsNullOrEmpty())
                    {
                        encryptedData = decryptedXml.ToObject<EncryptedData>();
                    }
                    else
                    {
                        "Encryption key mismatch. Exiting application".ShowWarning();
                        Application.Exit();
                    }
                }
                catch 
                {
                    "Encryption key mismatch. Exiting application".ShowWarning();
                    Application.Exit();
                }
            }
            if(encryptedData == null)
            {
                _encryptedFileName.AsFile(true);
                encryptedData = new EncryptedData();
            }
            Hide();
            var form1 = new Form1(encryptedData, txtEncryptionKey.Text);
            form1.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
